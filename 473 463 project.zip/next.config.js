module.exports = {
    experimental: {
      externalDir: true,
    },
  };