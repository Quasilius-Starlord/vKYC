from gettext import install
from django import forms
from django.conf import settings
from django.core.mail import send_mail

    