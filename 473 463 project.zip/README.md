npm install --save react-spinners
# vKYC
Blockchain-based one-time video KYC solution which can be used by a consortium of banks and other organisations that require their customers to go through KYC process.
