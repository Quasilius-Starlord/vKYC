import web3 from './web3';
import KycFactory from './build/KycFactory.json';


const instance = new web3.eth.Contract(
	KycFactory.abi,
	'0x705C3A99decFEe2253372C4FfB9bc6Fa7Fe83690'
	);

export default instance;